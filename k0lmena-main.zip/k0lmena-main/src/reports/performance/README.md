Directory for Performance Reports.

By Underc0de Team.