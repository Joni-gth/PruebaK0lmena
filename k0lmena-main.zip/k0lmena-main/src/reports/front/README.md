Directory for Front Reports.

By Underc0de Team.