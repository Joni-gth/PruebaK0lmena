Directory for API Reports.

By Underc0de Team.