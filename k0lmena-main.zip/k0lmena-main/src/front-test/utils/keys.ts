export enum KEYS_ENUM {
    ENTER = "Enter",
    ARROW_UP = "Arrow Up",
    ARROW_DOWN = "Arrow Down"
}