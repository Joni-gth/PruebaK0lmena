import 'dotenv/config'

export const BASEURL = process.env.BASEURL;