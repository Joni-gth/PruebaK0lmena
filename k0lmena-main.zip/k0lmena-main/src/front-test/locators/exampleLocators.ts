export const inputLabel = 'Buscar productos, marcas y má';
export const buttonSearch = 'div.nav-icon-search';
export const divResult = 'Autos, Motos y OtrosAutos y';
